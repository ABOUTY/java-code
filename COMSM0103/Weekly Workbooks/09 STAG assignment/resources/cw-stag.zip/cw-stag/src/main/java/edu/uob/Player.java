package edu.uob;

import java.util.HashSet;

public class Player extends GameEntity{
    private String location;
    private HashSet<String> inv;
    private int heart;
    public Player(String name, String description, String location) {
        super(name, description);
        this.location = location;
        this.inv = new HashSet<>();
        this.heart = 5;
    }

    public String getLocation() {
        return location;
    }

    public HashSet<String> getInv() {
        return inv;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getHeart() {
        return heart;
    }

    public void setHeart(int heart) {
        this.heart = heart;
    }
}
