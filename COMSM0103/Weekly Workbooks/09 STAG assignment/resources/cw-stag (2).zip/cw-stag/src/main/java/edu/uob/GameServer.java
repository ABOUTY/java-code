package edu.uob;

import com.alexmerz.graphviz.ParseException;
import com.alexmerz.graphviz.Parser;
import com.alexmerz.graphviz.objects.Edge;
import com.alexmerz.graphviz.objects.Graph;
import com.alexmerz.graphviz.objects.Node;
import com.alexmerz.graphviz.objects.PortNode;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Paths;
import java.util.*;

public final class GameServer {
    private static HashMap<String, Location> locHashMap;
    private static HashMap<String, HashSet<GameAction>> actHashMap;
    private static final char END_OF_TRANSMISSION = 4;

    public static void main(String[] args) throws IOException {
        File entitiesFile = Paths.get("config" + File.separator + "basic-entities.dot").toAbsolutePath().toFile();
        File actionsFile = Paths.get("config" + File.separator + "basic-actions.xml").toAbsolutePath().toFile();
        GameServer server = new GameServer(entitiesFile, actionsFile);
        server.blockingListenOn(8888);
    }

    /**
    * Do not change the following method signature or we won't be able to mark your submission
    * Instanciates a new server instance, specifying a game with some configuration files
    *
    * @param entitiesFile The game configuration file containing all game entities to use in your game
    * @param actionsFile The game configuration file containing all game actions to use in your game
    */
    public GameServer(File entitiesFile, File actionsFile) {
        // TODO implement your server logic here
        // Load entities and actions from files
        loadEntities(entitiesFile);
        loadActions(actionsFile);

        // test print
        System.out.println("locHashMap.keySet(): " + locHashMap.keySet());
        System.out.println("actHashMap.keySet(): " + actHashMap.keySet());

        System.out.println("Load over\n");
    }

    // load entities from file
    private void loadEntities(File entitiesFile) {
        HashMap<String, Location> locationHashMap = new HashMap<>();
        System.out.println("load entities");
        try {
            Parser parser = new Parser();
            FileReader reader = new FileReader(entitiesFile);
            parser.parse(reader);
            Graph wholeDocument = parser.getGraphs().get(0);
            ArrayList<Graph> sections = wholeDocument.getSubgraphs();
            ArrayList<Graph> locations = sections.get(0).getSubgraphs();
            for (Graph cluster : locations) {
                Node clusterNode = cluster.getNodes(true).get(0);
                String locationName = clusterNode.getId().getId();
                Location location = new Location(locationName, clusterNode.getAttribute("description"));
                ArrayList<Graph> entityList = cluster.getSubgraphs();
                for (Graph entity : entityList) {
                    String entityName = entity.getId().getId();
                    EntitySet entitySet = EntitySet.getByEntityName(entityName);

                    if (entitySet == EntitySet.CHARACTER) {
                        HashMap<String, Character> characterHashMap = new HashMap<>();
                        for (Node node : entity.getNodes(true)) {
                            String name = node.getId().getId();
                            String des = node.getAttribute("description");
                            characterHashMap.put(name, new Character(name, des));
                        }
                        location.setCharacterHashMap(characterHashMap);
                    } else if (entitySet == EntitySet.ARTEFACT) {
                        HashMap<String, Artefact> artefactHashMap = new HashMap<>();
                        for (Node node : entity.getNodes(true)) {
                            String name = node.getId().getId();
                            String des = node.getAttribute("description");
                            artefactHashMap.put(name, new Artefact(name, des));
                        }
                        location.setArtefactHashMap(artefactHashMap);
                    } else if (entitySet == EntitySet.FURNITURE) {
                        HashMap<String, Furniture> furnitureHashMap = new HashMap<>();
                        for (Node node : entity.getNodes(true)) {
                            String name = node.getId().getId();
                            String des = node.getAttribute("description");
                            furnitureHashMap.put(name, new Furniture(name, des));
                        }
                        location.setFurnitureHashMap(furnitureHashMap);
                    }
                }
                locationHashMap.put(locationName, location);
            }

            // add path
            ArrayList<Edge> paths = sections.get(1).getEdges();
            for(Edge path: paths){
                Node fromLocation = path.getSource().getNode();
                String fromName = fromLocation.getId().getId();
                Node toLocation = path.getTarget().getNode();
                String toName = toLocation.getId().getId();
                locationHashMap.get(fromName).addToNameHashMap(toName, locationHashMap.get(toName));
            }

            locHashMap = locationHashMap;

        } catch (FileNotFoundException | ParseException fnfe) {
            System.out.println("Exception");
        }

    }

    // load actions from file
    private void loadActions(File actionsFile) {
        System.out.println("Load actions");
        HashMap<String, HashSet<GameAction>> actionHashMap = new HashMap<>();
        // logic to read and parse actions from the file
        try {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse(actionsFile);
            Element root = document.getDocumentElement();
            NodeList actions = root.getChildNodes();
            // Get the first action (only the odd items are actually actions - 1, 3, 5 etc.)
            for (int i = 1; i < actions.getLength(); ) {
                Element action = (Element) actions.item(i);
                
                NodeList triggerList = action.getElementsByTagName("triggers");
                String[] trigger = triggerList.item(0).getTextContent().replaceAll(" ", "").trim().split("\n");
                HashSet<String> triggerSet = new HashSet<>(Arrays.asList(trigger));

                NodeList subjectsList = action.getElementsByTagName("subjects");
                String[] subjects = subjectsList.item(0).getTextContent().replaceAll(" ", "").trim().split("\n");
                HashSet<String> subjectsSet = new HashSet<>(Arrays.asList(subjects));


                NodeList consumedList = action.getElementsByTagName("consumed");
                String[] consumed = consumedList.item(0).getTextContent().replaceAll(" ", "").trim().split("\n");
                HashSet<String> consumedSet = new HashSet<>(Arrays.asList(consumed));

                NodeList producedList = action.getElementsByTagName("produced");
                String[] produced = producedList.item(0).getTextContent().replaceAll(" ", "").trim().split("\n");
                HashSet<String> producedSet = new HashSet<>(Arrays.asList(produced));

                NodeList narrationList = action.getElementsByTagName("narration");
                String narration = narrationList.item(0).getTextContent();

                GameAction gameAction = new GameAction(triggerSet, subjectsSet, consumedSet, producedSet, narration);
                for (String s: trigger) {
                    if(actionHashMap.get(s) == null){
                        HashSet<GameAction> gameActions = new HashSet<>();
                        gameActions.add(gameAction);
                        actionHashMap.put(s, gameActions);
                    }else{
                        HashSet<GameAction> gameActions = actionHashMap.get(s);
                        gameActions.add(gameAction);
                    }

                }
                i += 2;

            }


        } catch(ParserConfigurationException | SAXException | IOException pce) {
            System.out.println("exception");
        }

        actHashMap = actionHashMap;
    }


    /**
    * Do not change the following method signature or we won't be able to mark your submission
    * This method handles all incoming game commands and carries out the corresponding actions.</p>
    *
    * @param command The incoming command to be processed
    */
    public String handleCommand(String command) {
        // TODO implement your server logic here
        // Split the command into its components
        String[] parts = command.trim().split("\\s+", 2);

        // Extract the action and target
        String action = parts[0].toLowerCase();
        String target = parts.length > 1 ? parts[1] : "";

        // Perform the action based on the command
        return switch (action) {
            case "inventory", "inv" -> listInventory();
            case "get" -> pickupArtifact(target);
            case "drop" -> dropArtifact(target);
            case "goto" -> movePlayer(target);
            case "look" -> lookAround();
            case "help" -> help();
            default -> otherAction();
        };
    }

    private String help() {
        return "inv, get, drop, goto, look, help";
    }

    private String otherAction() {
        return "hit, unlock, cut, cutdown, attack, chop, open, drink, fight";
    }

    // list inventory
    private String listInventory() {
        return "";
    }

    // pick up an artifact
    private String pickupArtifact(String artifact) {
        return artifact;
    }

    // drop an artifact
    private String dropArtifact(String artifact) {
        return artifact;
    }

    // move the player to a new location
    private String movePlayer(String location) {
        return location;
    }

    // look around the current location
    private String lookAround() {
        return "";
    }

    /**
    * Do not change the following method signature or we won't be able to mark your submission
    * Starts a *blocking* socket server listening for new connections.
    *
    * @param portNumber The port to listen on.
    * @throws IOException If any IO related operation fails.
    */
    public void blockingListenOn(int portNumber) throws IOException {
        try (ServerSocket s = new ServerSocket(portNumber)) {
            System.out.println("Server listening on port " + portNumber);
            while (!Thread.interrupted()) {
                try {
                    blockingHandleConnection(s);
                } catch (IOException e) {
                    System.out.println("Connection closed");
                }
            }
        }
    }

    /**
    * Do not change the following method signature or we won't be able to mark your submission
    * Handles an incoming connection from the socket server.
    *
    * @param serverSocket The client socket to read/write from.
    * @throws IOException If any IO related operation fails.
    */
    private void blockingHandleConnection(ServerSocket serverSocket) throws IOException {
        try (Socket s = serverSocket.accept();
        BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()))) {
            System.out.println("Connection established");
            String incomingCommand = reader.readLine();
            if(incomingCommand != null) {
                System.out.println("Received message from " + incomingCommand);
                String result = handleCommand(incomingCommand);
                writer.write(result);
                writer.write("\n" + END_OF_TRANSMISSION + "\n");
                writer.flush();
            }
        }
    }
}
