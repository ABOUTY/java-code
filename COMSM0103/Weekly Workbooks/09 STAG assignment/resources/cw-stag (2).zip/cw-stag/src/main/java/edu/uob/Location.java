package edu.uob;

import java.util.HashMap;

public class Location extends GameEntity{
    HashMap<String, Artefact> artefactHashMap;
    HashMap<String, Furniture> furnitureHashMap;
    HashMap<String, Character> characterHashMap;
    HashMap<String, Location> toNameHashMap;

    public Location(String name, String description) {
        super(name, description);
        artefactHashMap = new HashMap<>();
        furnitureHashMap = new HashMap<>();
        characterHashMap = new HashMap<>();
        toNameHashMap = new HashMap<>();
    }

    public HashMap<String, Artefact> getArtefactHashMap() {
        return artefactHashMap;
    }

    public void setArtefactHashMap(HashMap<String, Artefact> artefactHashMap) {
        this.artefactHashMap = artefactHashMap;
    }

    public HashMap<String, Furniture> getFurnitureHashMap() {
        return furnitureHashMap;
    }

    public void setFurnitureHashMap(HashMap<String, Furniture> furnitureHashMap) {
        this.furnitureHashMap = furnitureHashMap;
    }

    public HashMap<String, Character> getCharacterHashMap() {
        return characterHashMap;
    }

    public void setCharacterHashMap(HashMap<String, Character> characterHashMap) {
        this.characterHashMap = characterHashMap;
    }

    public HashMap<String, Location> getToNameHashMap() {
        return toNameHashMap;
    }

    public void setToNameHashMap(HashMap<String, Location> toNameHashMap) {
        this.toNameHashMap = toNameHashMap;
    }

    public void addToNameHashMap(String name, Location location) {
        this.toNameHashMap.put(name, location);
    }
}
